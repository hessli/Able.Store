﻿using StackExchange.Redis;

namespace Able.Store.Infrastructure.Cache
{
    public interface ICacheStorage: ICacheReadOnly
    {
        void Delete<K>(K key, int dataBaseIndex) where K : class;
        void Delete<K>(K[] keys, int dataBaseIndex) where K : class;
        void Add<KeyId>(ICacheModel<KeyId> cacheModel) where KeyId : class;
        void Update<KeyId>(ICacheModel<KeyId> cacheModel) where KeyId : class;

        void RedisPublish(string channel, string value, int databaseIndex);
    }


    


}
