﻿using StackExchange.Redis;

namespace Able.Store.Infrastructure.Cache
{
    public interface ICacheUnit<T> where T : class
    {
        T GetDatabase(int dataBaseIndex=0);
        void Delete<K>(K key, int dataBaseIndex) where K : class;
        void Delete<K>(K[] keys, int dataBaseIndex) where K : class;
        void Add<KeyId>(ICacheModel<KeyId> cacheModel) where KeyId : class;
        void Update<KeyId>(ICacheModel<KeyId> cacheModel) where KeyId : class;
    }
    public interface IRedisUnit : ICacheUnit<IDatabase> 
    {
        void RedisPublish(RedisChannel channel, RedisValue value, int databaseIndex);
    }
}
