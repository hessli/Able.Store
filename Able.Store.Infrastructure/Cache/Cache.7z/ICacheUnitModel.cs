﻿using System;

namespace Able.Store.Infrastructure.Cache
{
    public interface ICacheUnitModel<KeyId> : ICacheModel<KeyId> where KeyId : class
    {
        TimeSpan? Expire { get; }
    }
}
