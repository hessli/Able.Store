﻿namespace Able.Store.Infrastructure.Cache.Local
{
    public class LocalCacheModel<KeyId> : ICacheModel<KeyId> where KeyId:class
    {
        public int? DataBaseIndex { get; set; }

        public KeyId Key { get; set; }
        public object Data { get; set; }
    }
}
