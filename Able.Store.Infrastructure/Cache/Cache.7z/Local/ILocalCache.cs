﻿using System.Collections;

namespace Able.Store.Infrastructure.Cache.Local
{
    public interface ILocalCache: ICacheUnit<Hashtable>
    {

    }
    
}
