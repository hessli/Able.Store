﻿using StackExchange.Redis;
using System.Collections.Generic;
using System.Linq;

namespace Able.Store.Infrastructure.Cache.Redis.Model
{
    public class RedisListModel:AbstractRedisModel
    {
        IList<RedisValue> _redisValues = new List<RedisValue>();
        public override RedisDataType RedisDataType
        {
            get
            {
                return RedisDataType.List;
            }
        }
        public int Count
        {

            get
            {
                return _redisValues.Count;
            }
        }

        internal RedisValue[] GetValues()
        {
            return _redisValues.ToArray();
        }

        internal RedisValue GetIndex(int index)
        {
            return _redisValues[index];
        }

        internal IEnumerable<RedisValue> RedisValues
        {
            get
            {
                return _redisValues;
            }
        }
        public void Add<T>(T body)
        {
            var data = RedisValue.Unbox(body);

            this._redisValues.Add(data);
        }
    }
}
