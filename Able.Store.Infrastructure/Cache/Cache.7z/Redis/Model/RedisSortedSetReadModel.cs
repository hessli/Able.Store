﻿namespace Able.Store.Infrastructure.Cache.Redis.Model
{
    public class RedisSortedSetReadModel : RedisReadOnlyModel
    {
        public override RedisDataType RedisDataType => RedisDataType.SortSet;
        public int Index { get; set; }

        public int Stop { get; set; }
    }
}
