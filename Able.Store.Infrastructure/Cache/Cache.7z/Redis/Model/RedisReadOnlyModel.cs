﻿namespace Able.Store.Infrastructure.Cache.Redis.Model
{
    public class RedisReadOnlyModel:ICacheModel<string>
    {
        public int? DataBaseIndex { get; set; }
        public string Key { get; set; }
        public virtual RedisDataType RedisDataType
        {
            get
            {

                return RedisDataType.String;
            }
        }
    }



  

}
