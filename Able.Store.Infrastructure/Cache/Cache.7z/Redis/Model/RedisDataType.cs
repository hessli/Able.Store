﻿namespace Able.Store.Infrastructure.Cache.Redis.Model
{
    public enum RedisDataType
    {
        List,
        String,
        Hash,
        Set,
        SortSet,
    }
}
