﻿using StackExchange.Redis;
using System.Collections.Generic;
using System.Linq;

namespace Able.Store.Infrastructure.Cache.Redis.Model
{
    public class RedisSortSetModel:AbstractRedisModel
    {
        IList<SortedSetEntry> _bodys = new List<SortedSetEntry>();

        public SortedSetEntry[] GetEntries()
        {

            return _bodys.ToArray();
        }
        public int Count
        {

            get
            {

                return _bodys.Count;
            }
        }
        /// <summary>
        /// 
        ///        第二个参数是 内容
        ///        第三个参数是 分值
        /// </summary>
        internal IEnumerable<SortedSetEntry> Bodys
        {
            get
            {

                return _bodys;
            }
        }
        public SortedSetEntry GetIndex(int index)
        {
            if (this._bodys.Count > index)
            {
                return this._bodys[index];
            }
            return default(SortedSetEntry);
        }

        public void Add<T>(T data, double score)
        {
            var redisValue = RedisValue.Unbox(data);

            var entry = new SortedSetEntry(redisValue, score);

            _bodys.Add(entry);
        }

        public override RedisDataType RedisDataType
        {

            get
            {
                return RedisDataType.SortSet;
            }
        }
    }
}
