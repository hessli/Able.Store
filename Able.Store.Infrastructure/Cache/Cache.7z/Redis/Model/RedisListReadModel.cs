﻿namespace Able.Store.Infrastructure.Cache.Redis.Model
{
    public class RedisListReadModel : RedisReadOnlyModel
    {
        public override RedisDataType RedisDataType
        {

            get
            {

                return RedisDataType.List;
            }
        }

        public int Index { get; set; }

        public int Stop { get; set; }

    }
}
