﻿using StackExchange.Redis;
using System.Collections.Generic;

namespace Able.Store.Infrastructure.Cache.Redis.Model
{
    public class RedisSetModel : AbstractRedisModel
    {
        IList<KeyValuePair<RedisValue, RedisValue>> _bodys = new List<KeyValuePair<RedisValue, RedisValue>>();
        public int Count
        {

            get
            {

                return _bodys.Count;
            }
        }

        public KeyValuePair<RedisValue, RedisValue> GetIndex(int index)
        {

            return _bodys[index];

        }
        internal HashEntry[] GetHashEntry()
        {

            HashEntry[] entry = new HashEntry[this.Count];

            for (var i = 0; i < this._bodys.Count; i++)
            {
                entry[i] = this._bodys[i];
            }

            return entry;
        }
        internal IEnumerable<KeyValuePair<RedisValue, RedisValue>> Bodys
        {
            get
            {

                return _bodys;
            }
        }
        public void Add<T>(string key, T body)
        {

            var data = RedisValue.Unbox(body);


            this._bodys.Add(new KeyValuePair<RedisValue, RedisValue>(key, data));
        }
        public override RedisDataType RedisDataType
        {
            get
            {
                return RedisDataType.Set;
            }
        }
    }
}
