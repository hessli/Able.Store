﻿using StackExchange.Redis;

namespace Able.Store.Infrastructure.Cache.Redis.Model
{
    public class RedisStrModel : AbstractRedisModel
    {
        public override RedisDataType RedisDataType => RedisDataType.String;

        public RedisValue RedisValue { get; private set; }

        public void SetRedisValue<T>(T value)
        {
            this.RedisValue = RedisValue.Unbox(value);
        }
    }
}
