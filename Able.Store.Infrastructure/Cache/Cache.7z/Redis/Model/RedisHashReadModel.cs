﻿using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Able.Store.Infrastructure.Cache.Redis.Model
{

    public class RedisHashReadModel : RedisReadOnlyModel
    {
        internal IList<RedisValue> _fileds = new List<RedisValue>();
        public override RedisDataType RedisDataType
        {
            get
            {
                return RedisDataType.Hash;
            }
        }
        internal RedisValue[] GetFileds()
        {
            return this._fileds.ToArray();
        }
        public void AddFiled(string filed)
        {
            this._fileds.Add(filed);
        }

    }
}
