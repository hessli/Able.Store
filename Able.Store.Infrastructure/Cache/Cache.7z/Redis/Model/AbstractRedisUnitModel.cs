﻿using System;

namespace Able.Store.Infrastructure.Cache.Redis.Model
{
    public abstract class AbstractRedisModel : ICacheUnitModel<string>
    {
        protected virtual int GetRandomNum()
        {
            Random ra = new Random(unchecked((int)DateTime.Now.Ticks));

             var data= ra.Next();

            return data;
        }
        public string Key { get; set; }

        private TimeSpan? _expire;
        public TimeSpan? Expire
        {
            get
            {
                if (_expire.HasValue)
                {
                    //加上随机数防止同一时间键过期的数量过多，导致缓存雪崩
                   var randomNum=GetRandomNum();
                    _expire.Value.Add(TimeSpan.FromSeconds(randomNum));
                }
                return _expire;
            }
            set
            {

                _expire = value;
            }
        }
        public abstract RedisDataType RedisDataType { get; }
        public int? DataBaseIndex { get; set; }
    }

}
