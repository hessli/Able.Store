﻿using StackExchange.Redis;
using System;

namespace Able.Store.Infrastructure.Cache.Redis
{
    public interface IRedisReadOnly : ICacheReadOnly
    {
        void Subscribe(RedisChannel channel, Action<RedisChannel, RedisValue> action);
        long HashDecrement(string key, string filed, int dataBaseIndex, TimeSpan timeSpan);
    }
}
