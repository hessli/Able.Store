﻿using Able.Store.Infrastructure.Cache.Redis.Model;
using StackExchange.Redis;
using System;

namespace Able.Store.Infrastructure.Cache.Redis
{
    public class RedisUnit: RedisContext,IRedisUnit
    {
        readonly TimeSpan LOWEST_EXPIRE = TimeSpan.FromMinutes(1);
        public void RemoveHashFiled(string key, string[] fileds, int dataBaseIndex)
        {
            var redisFileds = new RedisValue[fileds.Length];

            for (var i = 0; i < fileds.Length; i++)
            {
                redisFileds[i] = fileds[i];
            }

            var database =GetDatabase(dataBaseIndex);

            database.HashDelete(key, redisFileds);
        }
        public void Remove(string key, string filed, int dataBaseIndex, RedisDataType type)
        {
            if (string.IsNullOrWhiteSpace(key)) return;

            var database = GetDatabase(dataBaseIndex);

            switch (type)
            {
                case RedisDataType.Hash:
                    database.HashDelete(key, filed);
                    break;
                case RedisDataType.List:
                    database.ListRemove(key, filed);
                    break;
                case RedisDataType.Set:
                    database.SetRemove(key, filed);
                    break;
                case RedisDataType.SortSet:
                    database.SortedSetRemove(key, filed);
                    break;
                case RedisDataType.String: throw new System.NotSupportedException();
            }
        }
        internal void StringAdd(RedisStrModel entity, When when)
        {
            if (entity == null) return;
            var database = GetDatabase(entity.DataBaseIndex.GetValueOrDefault());
            database.StringSet(entity.Key, entity.RedisValue, when: when, expiry: entity.Expire);
        }
        internal void SortSetAdd(RedisSortSetModel model, When when)
        {
            if (model.Count > 0) return;

            var database = GetDatabase(model.DataBaseIndex.GetValueOrDefault());
            if (model.Count == 1)
            {
                var element = model.GetIndex(0);
                database.SortedSetAdd(model.Key, element.Element, element.Score, when);
            }
            else
            {
                database.SortedSetAdd(model.Key, model.GetEntries(), when);
            }

            if (model.Expire.HasValue && model.Expire.Value > this.LOWEST_EXPIRE)
            {
                database.KeyExpire(model.Key, model.Expire.Value);
            }

        }
        internal void ListAdd(RedisListModel model, When when)
        {

            if (model.Count == 0)
                return;

            var database =GetDatabase(model.DataBaseIndex.GetValueOrDefault());

            if (model.Count == 1)
            {
                database.ListLeftPush(model.Key, model.GetIndex(0), when);
            }
            else
            {
                database.ListLeftPush(model.Key, model.GetValues());
            }

            if (model.Expire.HasValue && model.Expire.Value > this.LOWEST_EXPIRE)
            {
                database.KeyExpire(model.Key, model.Expire.Value);
            }
        }
        internal void HashAdd(RedisSetModel model, When when)
        {


            if (model.Count == 0) return;

            var database =GetDatabase(model.DataBaseIndex.GetValueOrDefault());

            if (model.Count == 1)
            {
                var data = model.GetIndex(0);
                database.HashSet(model.Key, hashField: data.Key, value: data.Value, when: when);
            }
            else
            {
                var entry = model.GetHashEntry();
                database.HashSet(model.Key, entry);
            }

            if (model.Expire.HasValue && model.Expire.Value > LOWEST_EXPIRE)
            {
                database.KeyExpire(model.Key, model.Expire.Value);
            }
        }
        public void Delete<K>(K[] keys,int dataBaseIndex) where K : class
        {
        
            if (keys == null || keys.Length==0) return;


            RedisKey[] keyValue = new RedisKey[keys.Length];

            if (keys.GetType() == typeof(string))
            {
                for (int i = 0; i < keys.Length; i++)
                {
                    keyValue[i] = keys[i].ToString();
                }
            } else
            {
                for (int i = 0; i < keys.Length; i++)
                {
                    keyValue[i] = keys[i].GetHashCode().ToString();
                }
            }

            var database = GetDatabase(dataBaseIndex);
         
            database.KeyDelete(keyValue);
        }
        public void Delete<K>(K key, int dataBaseIndex) where K : class
        {
            if (key == null) return;

            if (key.ToString() == string.Empty) return;

            K[] keys= new K[] { key};

            Delete(keys, dataBaseIndex);
        }
        public void Add<KeyId>(ICacheModel<KeyId> cacheModel) where KeyId : class
        {
            switch (((AbstractRedisModel)cacheModel).RedisDataType)
            {
                case RedisDataType.Hash:
                    HashAdd((RedisSetModel)cacheModel, When.NotExists);
                    break;
                case RedisDataType.List:
                    ListAdd((RedisListModel)cacheModel, When.NotExists);
                    break;
                case RedisDataType.SortSet:
                    SortSetAdd((RedisSortSetModel)cacheModel, When.NotExists);
                    break;
                case RedisDataType.String:
                    this.StringAdd((RedisStrModel)cacheModel, When.NotExists);
                    break;
            }
        }
        public void Update<KeyId>(ICacheModel<KeyId> cacheModel) where KeyId : class
        {
            switch (((AbstractRedisModel)cacheModel).RedisDataType)
            {
                case RedisDataType.Hash:
                    HashAdd((RedisSetModel)cacheModel, When.Always);
                    break;
                case RedisDataType.List:
                    ListAdd((RedisListModel)cacheModel, When.Always);
                    break;
                case RedisDataType.SortSet:
                    SortSetAdd((RedisSortSetModel)cacheModel, When.Always);
                    break;
                case RedisDataType.String:
                    this.StringAdd((RedisStrModel)cacheModel, When.Always);
                    break;
            }
        }

        public void RedisPublish(RedisChannel channel,RedisValue value,  int databaseIndex)
        {
            var dataBase= base.GetDatabase(databaseIndex);

            dataBase.Publish(channel,value);
          }
    }
}
