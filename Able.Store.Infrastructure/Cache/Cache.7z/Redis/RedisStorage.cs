﻿using Able.Store.Infrastructure.Cache.Redis.Model;
using Able.Store.Infrastructure.Utils;
using StackExchange.Redis;
using System;
using System.Collections.Generic;

namespace Able.Store.Infrastructure.Cache.Redis
{
    public class RedisStorage : ICacheStorage, IRedisReadOnly
    {
        private RedisUnit _unitOfWork;
        public RedisStorage(ICacheUnit<IDatabase> CacheUnit)
        {
            _unitOfWork = (RedisUnit)CacheUnit;
        }
        public void Add<KeyId>(ICacheModel<KeyId> cacheModel) where KeyId : class
        {
            _unitOfWork.Add(cacheModel);
        }

        public void Delete<K>(K key, int dataBaseIndex) where K : class
        {
            _unitOfWork.Delete(key, dataBaseIndex);
        }
        public void Delete<K>(K[] keys, int dataBaseIndex) where K : class
        {
            _unitOfWork.Delete(keys, dataBaseIndex);
        }

        public void Update<KeyId>(ICacheModel<KeyId> cacheModel) where KeyId : class
        {
            _unitOfWork.Update(cacheModel);
        }
        public bool Exists<KeyId>(ICacheModel<KeyId> cacheModel) where KeyId : class
        {
            var database = _unitOfWork.GetDatabase(cacheModel.
                DataBaseIndex.GetValueOrDefault());

            return database.KeyExists(cacheModel.Key.ToString());
        }
        public IList<Value> GetList<KeyId, Value>(ICacheModel<KeyId> cacheModel) where KeyId : class
        {
            var model = (RedisReadOnlyModel)cacheModel;

            RedisValue[] values = default(RedisValue[]);

            IList<Value> results = new List<Value>();

            switch (model.RedisDataType)
            {
                case RedisDataType.String:
                    var data =
                     values = new RedisValue[] {
                        this.GetStr(model)
                     };
                    break;
                case RedisDataType.Hash:
                    values = HashGet((RedisHashReadModel)model);
                    break;
                case RedisDataType.List:
                    values = ListRange((RedisListReadModel)model);
                    break;
                case RedisDataType.SortSet:
                    values = SortedSetRangeByRank((RedisSortedSetReadModel)model);
                    break;
            }
            foreach (var item in values)
            {
                var data = JsonPase.Deserialize<Value>(item);

                results.Add(data);
            }
            return results;
        }
       public  void RedisPublish(RedisChannel channel, RedisValue value, int databaseIndex)
        {
              _unitOfWork.RedisPublish(channel,value,databaseIndex);

        }
        internal RedisValue GetStr(RedisReadOnlyModel model)
        {
            var dataBase = _unitOfWork.
          GetDatabase(model.DataBaseIndex.GetValueOrDefault());

            var data = dataBase.StringGet(model.Key);
            return data;
        }

        public RedisValue HashGetSinger(RedisHashReadModel reidsHashReadModel)
        {
            var dataBase = _unitOfWork.GetDatabase(reidsHashReadModel.DataBaseIndex.GetValueOrDefault());

            var fileds = reidsHashReadModel.GetFileds();

            var data = dataBase.HashGet(reidsHashReadModel.Key, fileds[0]);

            return data;
        }
        internal RedisValue[] HashGet(RedisHashReadModel model)
        {
            var dataBase = _unitOfWork.GetDatabase(model.DataBaseIndex.GetValueOrDefault());

            var data = dataBase.HashGet(model.Key, model.GetFileds());

            return data;
        }

        internal RedisValue[] SortedSetRangeByRank(RedisSortedSetReadModel readModel)
        {
            var dataBase = _unitOfWork.GetDatabase(readModel.DataBaseIndex.GetValueOrDefault());

            var data = dataBase.SortedSetRangeByRank(readModel.Key, readModel.Index, readModel.Stop);

            return data;
        }

        internal RedisValue[] ListRange(RedisListReadModel model)
        {
            var dataBase = _unitOfWork.GetDatabase(model.DataBaseIndex.GetValueOrDefault());

            var data = dataBase.ListRange(model.Key, model.Index, model.Stop);
            return data;
        }

        internal RedisValue ListByIndex(RedisListReadModel model)
        {
            var dataBase = _unitOfWork.GetDatabase(model.DataBaseIndex.GetValueOrDefault());

            var data = dataBase.ListGetByIndex(model.Key, model.Index);

            return data;
        }
        public Value GetSinger<KeyId, Value>(ICacheModel<KeyId> cacheModel) where KeyId : class
        {
            var model = (RedisReadOnlyModel)cacheModel;
            RedisValue value = default(RedisValue);
            switch (model.RedisDataType)
            {
                case RedisDataType.String:
                    value = this.GetStr(model);
                    break;
                case RedisDataType.Hash:
                    value = this.HashGetSinger((RedisHashReadModel)model);
                    break;
                case RedisDataType.List:
                    value = ListByIndex((RedisListReadModel)model);
                    break;
            }
            return JsonPase.Deserialize<Value>(value);
        }

        public void Subscribe(RedisChannel channel,Action<RedisChannel,RedisValue> action)
        {
            var dataBase = _unitOfWork.GetSubscriber();

             dataBase.Subscribe(channel,action);
        }
        public long HashDecrement(string key, string filed,int dataBaseIndex, TimeSpan timeSpan)
        {
            var dataBase = _unitOfWork.GetDatabase(dataBaseIndex);

            var index = dataBase.HashIncrement(key, filed, 1);

                dataBase.KeyExpire(key,timeSpan);

            return index;
        }


      
    }
}
