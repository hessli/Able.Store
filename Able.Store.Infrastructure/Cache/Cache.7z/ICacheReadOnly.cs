﻿using System.Collections.Generic;
namespace Able.Store.Infrastructure.Cache
{
    public interface ICacheReadOnly
    {
        bool Exists<KeyId>(ICacheModel<KeyId> cacheModel) where KeyId : class;
        IList<Value> GetList<KeyId, Value>(ICacheModel<KeyId> cacheModel) where KeyId : class;
        Value GetSinger<KeyId,Value>(ICacheModel<KeyId> cacheModel) where KeyId : class;
    }

}
