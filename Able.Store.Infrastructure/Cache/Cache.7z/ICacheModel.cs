﻿namespace Able.Store.Infrastructure.Cache
{
    public interface ICacheModel<KeyId> where KeyId : class
    {
        int? DataBaseIndex { get; }
        KeyId Key { get; }
    }

}
